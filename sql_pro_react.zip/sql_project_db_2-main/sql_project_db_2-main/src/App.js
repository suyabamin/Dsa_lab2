import Users from "./components/Users";
import Rooms from "./components/Rooms";
import Bookings from "./components/Bookings";
import Payments from "./components/Payments";
import Reviews from "./components/Reviews";

function App() {
  return (
    <div>
      <h1>Hotel Booking Management System</h1>
      <Users />
      <Rooms />
      <Bookings />
      <Payments />
      <Reviews />
    </div>
  );
}

export default App;
