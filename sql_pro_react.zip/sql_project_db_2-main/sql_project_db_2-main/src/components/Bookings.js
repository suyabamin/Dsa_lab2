import React, { useEffect, useState } from "react";
import API_BASE from "../api";

function Bookings() {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetch(`${API_BASE}/bookings`)
      .then(res => res.json())
      .then(data => setBookings(data));
  }, []);

  return (
    <div>
      <h2>Bookings</h2>
      <table border="1">
        <tr>
          <th>ID</th><th>User</th><th>Room</th><th>Status</th>
        </tr>
        {bookings.map(b => (
          <tr key={b.booking_id}>
            <td>{b.booking_id}</td>
            <td>{b.user_name}</td>
            <td>{b.room_number}</td>
            <td>{b.booking_status}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default Bookings;
