import React, { useEffect, useState } from "react";
import API_BASE from "../api";

function Reviews() {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    fetch(`${API_BASE}/reviews`)
      .then(res => res.json())
      .then(data => setReviews(data));
  }, []);

  return (
    <div>
      <h2>Reviews</h2>
      <ul>
        {reviews.map(r => (
          <li key={r.review_id}>
            {r.user_name} → Room {r.room_number} → ⭐ {r.rating}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Reviews;
