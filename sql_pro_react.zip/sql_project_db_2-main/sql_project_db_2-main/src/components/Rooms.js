import React, { useEffect, useState } from "react";
import API_BASE from "../api";

function Rooms() {
  const [rooms, setRooms] = useState([]);

  useEffect(() => {
    fetch(`${API_BASE}/rooms`)
      .then(res => res.json())
      .then(data => setRooms(data));
  }, []);

  return (
    <div>
      <h2>Rooms</h2>
      <table border="1">
        <tr>
          <th>ID</th><th>Number</th><th>Type</th><th>Price</th><th>Status</th>
        </tr>
        {rooms.map(r => (
          <tr key={r.room_id}>
            <td>{r.room_id}</td>
            <td>{r.room_number}</td>
            <td>{r.room_type}</td>
            <td>{r.price}</td>
            <td>{r.status}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default Rooms;
