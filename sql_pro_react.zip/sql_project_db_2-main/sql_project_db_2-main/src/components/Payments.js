import React, { useEffect, useState } from "react";
import API_BASE from "../api";

function Payments() {
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    fetch(`${API_BASE}/payments`)
      .then(res => res.json())
      .then(data => setPayments(data));
  }, []);

  return (
    <div>
      <h2>Payments</h2>
      <table border="1">
        <tr>
          <th>ID</th><th>Booking</th><th>Amount</th><th>Status</th>
        </tr>
        {payments.map(p => (
          <tr key={p.payment_id}>
            <td>{p.payment_id}</td>
            <td>{p.booking_id}</td>
            <td>{p.amount}</td>
            <td>{p.payment_status}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default Payments;
